Anonymous machine-readable online supplement

These seven aggregate CSV files provide the complete cell, score-stratum,
label-category, and common-panel adjacent-threshold rows summarized by PDF
Tables S6B, S6D, S6F, S6J, and S6K. S6C and S6E are machine-readable-only
tables because their 200-row
layouts are unsuitable for a reviewer PDF.

The joint-block columns preserve the executed calculation while using active
reporting names. A threshold flag is a retrospective nominal reporting flag,
not post-selection FWER control, proof of conformal-theorem failure, or proof
of exchangeability when absent. Label-Mondrian rows are a deterministic
sensitivity, not a selected repair, class-conditional transport guarantee, or
fairness result. No row contains author identity, repository coordinates,
commits, tags, hashes, local paths, or loan-level data.

The common-panel tables report all 175 stratum transitions and all 35
learner-level aggregates. Their sharp all-candidate response bounds assign each
unresolved loan once and share that completion across both thresholds. They are
descriptive finite-archive identities, not temporal-validity tests, slopes,
rankings, or selected-transition evidence.

