Anonymous machine-readable online supplement

These nineteen aggregate CSV files provide the complete calibration-fit, cell,
score-stratum, label-category, common-panel adjacent-threshold,
residual-distribution, marginal score-outcome, calibrator-pair, decision-catalog,
and funded-estimand rows summarized by PDF Tables S2C, S6B, S6D, S6F,
S6J--S6P, and S9G--S9L. S6C, S6E, S6M, and the stratum rows of S6O are
machine-readable-first layouts because their 192--200-row grids are unsuitable
for complete display in a reviewer PDF.

Historical display-label crosswalk (PDF -> canonical CSV stem):
S2 -> table6_credit_controls + tableS2_credit_prediction_metrics
S6 -> table1_coverage_windows + tableS6A_conformal_set_diagnostics
S7 Panels A--B -> table2_phase_transition
S7B -> tableS5_label_lag_sensitivity
S7C -> tableS9_missingness_encoding_sensitivity
S7F -> tableS11_fit_label_completion
S9 -> table5_two_ruler_tracks
S9B--S9C -> tableS6_endpoint_availability_sensitivity
S9D--S9E -> tableS7_portfolio_structure_sensitivity
S9F -> tableS12_allocation_granularity
S10 -> tableS1_named_comparators
S11 -> table4_direction_summary

Those aggregate presentation files are not duplicated in this reviewer
archive. Archive entries use their PDF suffix directly; for example,
Table_S6B_exchangeability_cells.csv is the complete machine-readable companion
to the PDF's Table S6B summary view.

The joint-block columns preserve the executed calculation while using active
reporting names. A threshold flag is a retrospective nominal reporting flag,
not post-selection FWER control, proof of conformal-theorem failure, or proof
of exchangeability when absent. Label-Mondrian rows are a deterministic
sensitivity, not a selected repair, class-conditional transport guarantee, or
fairness result. No row contains author identity, repository coordinates,
commits, tags, hashes, local paths, or loan-level data.

The common-panel tables report all 175 stratum transitions and all 35
learner-level aggregates. Their sharp all-candidate response bounds assign each
unresolved loan once and share that completion across both thresholds. They are
descriptive finite-archive identities, not temporal-validity tests, slopes,
rankings, or selected-transition evidence.

The residual tables report cellwise sharp ranges for two one-sided empirical
CDF discrepancies, not a KS test or global stochastic ordering. The marginal
table is finite-archive partial identification, not individual or conditional
calibration. Decision-catalog rows concern the worst loss over the fixed
catalog, not every policy. Funded-estimand rows keep count, invested-dollar,
and fixed-capital weightings distinct and do not establish FCR or selected-set
validity.

The calibrator tables report all four same-sample 2011 fit diagnostics, all 192
pooled-plus-stratum evaluation cells, and all 288 pairwise cells under one
common uncalibrated-probability taxonomy. Pairwise bounds share each loanwise
unresolved completion across the two methods. These retrospective rows select
no calibrator, rank no method from the fit diagnostics, transfer no Venn--Abers
multiprobability guarantee to the scalar score, and perform no portfolio
optimization. The separate primary portfolio analysis already uses the
pre-existing Platt score; none of the three alternative maps is propagated.

The set-preserving embedding tables report the full allocation-change and
descriptive direction censuses from a retrospective post-inspection
sensitivity. Identical binary prediction sets do not select an embedding,
ruler, coordinate, or policy, and the reported directions are neither causal
nor confirmatory.

