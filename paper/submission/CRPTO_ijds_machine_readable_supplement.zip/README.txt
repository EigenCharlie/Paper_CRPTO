Anonymous machine-readable online supplement

These sixteen aggregate CSV files provide the complete cell, score-stratum,
label-category, common-panel adjacent-threshold, residual-distribution,
marginal score-outcome, decision-catalog, and funded-estimand rows summarized
by PDF Tables S6B, S6D, S6F, S6J--S6N, and S9G--S9L. S6C, S6E, and S6M are
machine-readable-only tables because their 200-row layouts are unsuitable for
a reviewer PDF.

The joint-block columns preserve the executed calculation while using active
reporting names. A threshold flag is a retrospective nominal reporting flag,
not post-selection FWER control, proof of conformal-theorem failure, or proof
of exchangeability when absent. Label-Mondrian rows are a deterministic
sensitivity, not a selected repair, class-conditional transport guarantee, or
fairness result. No row contains author identity, repository coordinates,
commits, tags, hashes, local paths, or loan-level data.

The common-panel tables report all 175 stratum transitions and all 35
learner-level aggregates. Their sharp all-candidate response bounds assign each
unresolved loan once and share that completion across both thresholds. They are
descriptive finite-archive identities, not temporal-validity tests, slopes,
rankings, or selected-transition evidence.

The residual tables report cellwise sharp ranges for two one-sided empirical
CDF discrepancies, not a KS test or global stochastic ordering. The marginal
table is finite-archive partial identification, not individual or conditional
calibration. Decision-catalog rows concern the worst loss over the fixed
catalog, not every policy. Funded-estimand rows keep count, invested-dollar,
and fixed-capital weightings distinct and do not establish FCR or selected-set
validity.

The set-preserving embedding tables report the full allocation-change and
descriptive direction censuses from a retrospective post-inspection
sensitivity. Identical binary prediction sets do not select an embedding,
ruler, coordinate, or policy, and the reported directions are neither causal
nor confirmatory.

